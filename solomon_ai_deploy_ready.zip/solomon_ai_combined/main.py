import os, json, hmac, base64, sqlite3, asyncio
from pathlib import Path
from datetime import datetime, timezone
from contextlib import contextmanager
from typing import Optional

import cv2
import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, Header, HTTPException, UploadFile, File, Form, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

load_dotenv()
DB_PATH = os.getenv("SOLOMON_DB", "solomon.db")
CAMERAS_FILE = Path(os.getenv("SOLOMON_CAMERAS_FILE", "cameras.json"))
ADMIN_TOKEN = os.getenv("SOLOMON_ADMIN_TOKEN", "").strip()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "").strip()
MODEL = os.getenv("SOLOMON_MODEL", "gpt-4.1-mini")
VISION_MODEL = os.getenv("SOLOMON_VISION_MODEL", MODEL)
WINDY_KEY = os.getenv("WINDY_WEBCAMS_API_KEY", "").strip()
WINDY_API = "https://api.windy.com/webcams/api/v3/webcams"

app = FastAPI(title="SOLOMON AI API", version="1.0.0")
origins = [x.strip() for x in os.getenv(
    "SOLOMON_CORS_ORIGINS", "http://127.0.0.1:5500,http://localhost:5500"
).split(",") if x.strip()]
app.add_middleware(CORSMiddleware, allow_origins=origins,
                   allow_credentials=False, allow_methods=["GET","POST","OPTIONS"],
                   allow_headers=["Content-Type","X-Solomon-Token"])

try:
    from openai import OpenAI
    ai = OpenAI(api_key=OPENAI_API_KEY) if OPENAI_API_KEY else None
except Exception:
    ai = None

def now():
    return datetime.now(timezone.utc).isoformat()

@contextmanager
def db():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    try:
        yield c
        c.commit()
    finally:
        c.close()

def init_db():
    with db() as c:
        c.execute("CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY, role TEXT, content TEXT, created_at TEXT)")
        c.execute("CREATE TABLE IF NOT EXISTS tasks(id INTEGER PRIMARY KEY, title TEXT, done INTEGER DEFAULT 0, created_at TEXT)")
        c.execute("CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY, event TEXT, details TEXT, created_at TEXT)")
init_db()

def event(name, details=""):
    with db() as c:
        c.execute("INSERT INTO events(event,details,created_at) VALUES(?,?,?)",
                  (name[:200], details[:1000], now()))

def auth(token: Optional[str]):
    if not ADMIN_TOKEN:
        raise HTTPException(503, "Configure SOLOMON_ADMIN_TOKEN on the server.")
    if not token or not hmac.compare_digest(token, ADMIN_TOKEN):
        raise HTTPException(401, "Invalid authorization token.")

def cameras():
    if not CAMERAS_FILE.exists():
        return {}
    try:
        value = json.loads(CAMERAS_FILE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        raise HTTPException(500, "Camera registry could not be read.")
    if not isinstance(value, dict):
        raise HTTPException(500, "Camera registry must be a JSON object.")
    return value

class Chat(BaseModel):
    message: str = Field(min_length=1, max_length=8000)
class Task(BaseModel):
    title: str = Field(min_length=1, max_length=300)
class Question(BaseModel):
    question: str = Field(default="Describe the visible scene.", max_length=1000)

@app.get("/")
def root():
    return {"assistant":"SOLOMON","status":"running","docs":"/docs"}

@app.get("/health")
def health():
    return {"assistant":"SOLOMON","status":"ok","ai_configured":bool(ai),
            "public_webcam_discovery_configured":bool(WINDY_KEY),"timestamp":now()}

@app.post("/chat")
def chat(body: Chat):
    msg = body.message.strip()
    with db() as c:
        c.execute("INSERT INTO messages(role,content,created_at) VALUES(?,?,?)",("user",msg,now()))
        rows = c.execute("SELECT role,content FROM messages ORDER BY id DESC LIMIT 12").fetchall()
    history = [{"role":r["role"],"content":r["content"]} for r in reversed(rows)]
    answer = "SOLOMON local fallback is active. Add OPENAI_API_KEY to enable AI responses. You said: " + msg[:500]
    if ai:
        try:
            r = ai.responses.create(model=MODEL,
                instructions="You are SOLOMON, a practical AI assistant. Be honest about uncertainty and system access.",
                input=history)
            answer = r.output_text
        except Exception:
            answer = "SOLOMON could not reach the AI model. Check the backend API key and network."
    with db() as c:
        c.execute("INSERT INTO messages(role,content,created_at) VALUES(?,?,?)",("assistant",answer,now()))
    event("chat","Chat response generated")
    return {"assistant":"SOLOMON","response":answer}

@app.get("/memory")
def memory(limit:int=Query(50,ge=1,le=200)):
    with db() as c:
        rows=c.execute("SELECT role,content,created_at FROM messages ORDER BY id DESC LIMIT ?",(limit,)).fetchall()
    return {"messages":[dict(r) for r in reversed(rows)]}

@app.get("/tasks")
def tasks():
    with db() as c: rows=c.execute("SELECT * FROM tasks ORDER BY id DESC").fetchall()
    return {"tasks":[dict(r) for r in rows]}

@app.post("/tasks")
def add_task(body:Task):
    with db() as c:
        cur=c.execute("INSERT INTO tasks(title,done,created_at) VALUES(?,0,?)",(body.title.strip(),now()))
        ident=cur.lastrowid
    event("task_created",body.title)
    return {"id":ident,"title":body.title.strip(),"done":False}

@app.get("/events")
def events(limit:int=Query(50,ge=1,le=200)):
    with db() as c: rows=c.execute("SELECT * FROM events ORDER BY id DESC LIMIT ?",(limit,)).fetchall()
    return {"events":[dict(r) for r in rows]}

@app.get("/cameras")
def list_cameras(x_solomon_token:Optional[str]=Header(None)):
    auth(x_solomon_token)
    out=[]
    for ident,c in cameras().items():
        if isinstance(c,dict) and c.get("url") and c.get("name"):
            out.append({"id":str(ident),"name":c["name"],
                        "latitude":c.get("latitude"),"longitude":c.get("longitude")})
    return {"assistant":"SOLOMON","cameras":out}

def capture(url):
    cap=cv2.VideoCapture(url)
    try:
        if not cap.isOpened(): raise RuntimeError("Camera connection failed")
        ok,frame=cap.read()
        if not ok or frame is None: raise RuntimeError("No frame received")
        ok,encoded=cv2.imencode(".jpg",frame,[int(cv2.IMWRITE_JPEG_QUALITY),85])
        if not ok: raise RuntimeError("Image encoding failed")
        return encoded.tobytes()
    finally: cap.release()

def vision(image_bytes, question):
    if not ai: raise HTTPException(503,"Set OPENAI_API_KEY to enable vision analysis.")
    b64=base64.b64encode(image_bytes).decode("ascii")
    try:
        r=ai.responses.create(model=VISION_MODEL,
            instructions="You are SOLOMON vision. Describe visible evidence accurately and distinguish observation from uncertainty.",
            input=[{"role":"user","content":[{"type":"input_text","text":question},
                {"type":"input_image","image_url":"data:image/jpeg;base64,"+b64}]}])
        return r.output_text
    except Exception:
        raise HTTPException(502,"Image analysis service failed.")

@app.post("/cameras/{camera_id}/analyze")
async def analyze_camera(camera_id:str, body:Question,
                         x_solomon_token:Optional[str]=Header(None)):
    auth(x_solomon_token)
    c=cameras().get(camera_id)
    if not isinstance(c,dict) or not c.get("url"): raise HTTPException(404,"Camera not registered.")
    try:
        frame=await asyncio.to_thread(capture,c["url"])
        result=await asyncio.to_thread(vision,frame,body.question)
    except HTTPException: raise
    except Exception: raise HTTPException(502,"Camera capture failed; check stream URL and connection.")
    event("camera_analyzed",str(c.get("name",camera_id)))
    return {"assistant":"SOLOMON","camera":c.get("name",camera_id),"analysis":result}

@app.post("/vision")
async def analyze_upload(image:UploadFile=File(...),
                         question:str=Form("Describe the visible scene."),
                         x_solomon_token:Optional[str]=Header(None)):
    auth(x_solomon_token)
    if image.content_type not in {"image/jpeg","image/png","image/webp"}:
        raise HTTPException(415,"Upload a JPEG, PNG, or WebP image.")
    content=await image.read()
    if not content or len(content)>8*1024*1024: raise HTTPException(413,"Image must be non-empty and at most 8 MB.")
    result=await asyncio.to_thread(vision,content,question[:1000])
    event("image_analyzed",image.filename or "uploaded image")
    return {"assistant":"SOLOMON","analysis":result}

@app.get("/public-webcams")
async def public_webcams(lat:float|None=Query(None,ge=-90,le=90),
                         lon:float|None=Query(None,ge=-180,le=180),
                         radius_km:int=Query(50,ge=1,le=250),
                         country:str|None=Query(None,min_length=2,max_length=3),
                         limit:int=Query(30,ge=1,le=50), offset:int=Query(0,ge=0,le=1000)):
    if not WINDY_KEY: raise HTTPException(503,"Set WINDY_WEBCAMS_API_KEY to enable public webcam discovery.")
    if (lat is None)!=(lon is None): raise HTTPException(400,"Provide both lat and lon, or neither.")
    params={"limit":limit,"offset":offset,"include":"categories,images,location,player,urls","lang":"en"}
    if lat is not None: params["nearby"]=f"{lat},{lon},{radius_km}"
    elif country: params["countries"]=country.upper()
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            res=await client.get(WINDY_API,params=params,headers={"X-WINDY-API-KEY":WINDY_KEY})
        if res.status_code in (401,403): raise HTTPException(502,"Webcam provider rejected API key or plan.")
        res.raise_for_status(); raw=res.json()
    except HTTPException: raise
    except (httpx.HTTPError,ValueError): raise HTTPException(502,"Public webcam provider unavailable or returned invalid data.")
    result=[]
    for item in raw.get("webcams",[]) if isinstance(raw,dict) else []:
        loc=item.get("location") or {}; images=item.get("images") or {}
        current=images.get("current") or images.get("daylight") or images.get("thumbnail") or {}
        urls=item.get("urls") or {}; player=item.get("player") or {}
        result.append({"id":str(item.get("webcamId") or item.get("id") or ""),
            "title":item.get("title") or item.get("name") or "Public webcam",
            "latitude":loc.get("latitude"),"longitude":loc.get("longitude"),
            "country":loc.get("country"),"city":loc.get("city"),
            "preview":current.get("preview") or current.get("thumbnail") or current.get("icon"),
            "webcam_url":urls.get("detail") or urls.get("webcam"),
            "player_url":player.get("live") or player.get("url"),
            "provider":"Windy.com Webcams","live_player_listed":bool(player.get("live"))})
    event("public_webcam_search",f"{len(result)} result(s)")
    return {"source":"Windy.com Webcams API","count":len(result),
            "total":raw.get("total") if isinstance(raw,dict) else None,
            "webcams":result,"note":"A directory listing does not guarantee a feed is currently live."}
