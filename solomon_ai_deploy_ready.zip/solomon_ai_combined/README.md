# SOLOMON AI combined backend

## Install
1. Copy `.env.example` to `.env` and configure your keys.
2. Copy `cameras.example.json` to `cameras.json`; replace the sample stream with a camera you own/are authorized to use, or set the file to `{}`.
3. `pip install -r requirements.txt`
4. `uvicorn main:app --host 127.0.0.1 --port 8000 --reload`
5. Visit `http://127.0.0.1:8000/docs`.

## Endpoints
- `GET /health`
- `POST /chat` JSON `{"message":"Hello SOLOMON"}`
- `GET /memory`
- `GET /tasks`, `POST /tasks` JSON `{"title":"Task"}`
- `GET /events`
- `GET /cameras` with `X-Solomon-Token`
- `POST /cameras/{camera_id}/analyze` with token and JSON `{"question":"Describe the scene."}`
- `POST /vision` multipart `image` and `question`, with token
- `GET /public-webcams?country=KE&limit=30`
- `GET /public-webcams?lat=-1.2864&lon=36.8172&radius_km=50`

`OPENAI_API_KEY` enables AI chat and vision. `WINDY_WEBCAMS_API_KEY` enables public webcam directory search; obtain it at https://api.windy.com/webcams. Keep API keys and camera credentials server-side.

This starter does not scan networks, bypass authentication, or access private cameras without permission. Public webcam listings may be offline. Use HTTPS, restricted CORS, rate limits, authentication, and firewall controls before production deployment.

## Deploy online (Render)
1. Upload this folder to a **private GitHub repository** (do not commit `.env`, API keys, or real camera credentials).
2. In Render, choose **New → Blueprint**, connect that repository, and let Render read `render.yaml`.
3. Enter `OPENAI_API_KEY` when prompted. `WINDY_WEBCAMS_API_KEY` is optional and only needed for the public webcam directory.
4. Deploy and wait for the `/health` health check to pass. Open the service URL plus `/docs` to test.
5. In Render's environment settings, set `SOLOMON_CORS_ORIGINS` to the exact HTTPS origin of the dashboard once it is hosted. The wildcard in this starter blueprint is convenient for initial setup but is not recommended for production.
6. The persistent disk keeps SQLite data and `cameras.json` across restarts. Create `/var/data/cameras.json` with `{}` first, then add only streams you own or are authorized to access. Do not put camera passwords in the frontend.

**Deployment caveats:** this blueprint provisions a paid Render Starter service and persistent disk; provider prices can change. The API key and hosting account are yours to supply. Deployment is not complete until you create the service in your account, supply the secrets, and verify the live health endpoint. This backend does not itself package an Android APK or host the dashboard frontend.
